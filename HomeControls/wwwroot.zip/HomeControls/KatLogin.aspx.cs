﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HomeControls
{
    public partial class KatLogin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            if(CheckLogin(tbUsername.Text, tbPassword.Text))
            {
                Response.Redirect("KatApp.aspx");
            }
        }






        public bool CheckLogin(string username, string password)
        {
            NallCrypt nc = new NallCrypt();
            string name = "";
            string query = "SELECT uname FROM nallwebc_admin.KatKeep_Login WHERE uname=@name AND pword=@pass";

            using (SqlConnection sqlCon = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["KatKeep"].ConnectionString))
            {
                
                using (SqlCommand cmd = new SqlCommand(query, sqlCon))
                {
                    cmd.Parameters.AddWithValue("@name", username);
                    cmd.Parameters.AddWithValue("@pass", nc.Encrypt(password));
                    try
                    {
                        sqlCon.Open();
                        name = (string)cmd.ExecuteScalar();
                    }
                    catch(Exception ex)
                    {

                    }
                    if(name == username)
                    {
                        lblMessage.Text = "User " + username + " logged in.";
                        Session["username"] = username;
                        return true;                        
                    }
                    else
                    {
                        lblMessage.Text = "User " + username + " not found.";
                        Session["username"] = "";
                        return false;                        
                    }
                        
                }
            }
        }
    }
}